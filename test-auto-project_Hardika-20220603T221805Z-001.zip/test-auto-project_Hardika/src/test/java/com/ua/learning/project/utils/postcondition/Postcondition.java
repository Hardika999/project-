package com.ua.learning.project.utils.postcondition;

public class Postcondition {

}
