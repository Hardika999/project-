package com.ua.learning.project.utils.precondition;

public class Precondition {

}
