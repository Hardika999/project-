package com.ua.learning.project.utils.test_constants;

public class TestConstants {

	public static final String firstName = "Ivan";
	public static final String lastName = "Petrov";
	public static final String birthday = "25/05/1988";
	public static final int age = 25;
}
