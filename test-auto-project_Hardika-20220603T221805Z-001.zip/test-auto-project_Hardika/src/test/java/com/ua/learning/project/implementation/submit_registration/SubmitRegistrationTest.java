package com.ua.learning.project.implementation.submit_registration;

import static org.testng.Assert.assertEquals;

import java.util.Arrays;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ua.learning.project.core.driver.Assignments;
import com.ua.learning.project.implementation.BaseTest;
import com.ua.learning.project.model.entity.RegistrationForm;
import com.ua.learning.project.model.pages.ui.implementation.login.LoginPage;
import com.ua.learning.project.model.pages.ui.implementation.menu.AbcMenu;
import com.ua.learning.project.model.pages.ui.implementation.menu.CDIMenu;
import com.ua.learning.project.model.pages.ui.implementation.menu.MainMenu;
import com.ua.learning.project.utils.test_constants.TestConstants;

public class SubmitRegistrationTest extends BaseTest {

	@Test
	void loginSystem() {
		LoginPage test = new LoginPage("http://www.google.com.ua/");
		test.openWindow();
	}

	@Test
	void testPolymorphysm() {
		AbcMenu test = new AbcMenu();
		test.selectMenu();

		CDIMenu test2 = new CDIMenu();
		test2.selectMenu();

		MainMenu test3 = new MainMenu();
		test3.selectMenu();
	}

	@Test
	void testPolymorphysm_2() {
		AbcMenu test = new AbcMenu();
		test.selectMenu();

	}

	@Test
	void RegistrationFormInstance() {
		RegistrationForm form = new RegistrationForm();
		System.out.println(form);
	}

	@Test
	void RegistrationFormInstanceWithParam() {
		RegistrationForm test = new RegistrationForm(TestConstants.firstName, TestConstants.lastName,
				TestConstants.birthday, TestConstants.age);
		System.out.println(test);
	}

	@Test
	void RegistrationFormInstanceWithHashCode() {
		RegistrationForm test = new RegistrationForm();
		test.setFirstName("Petrov");
		test.hashCode();

	}

	@Test
	void combineLetters() {
		Assignments test = new Assignments();
		assertEquals("abcabc", test.threeWords("aa", "bb", "cc"));

	}

	@Test
	void countVovels() {
		Assignments test = new Assignments();
		assertEquals(5, test.countVovel("abracadabra"));

	}

	@Test
	void listSubstract() {
		Assignments test = new Assignments();

		int[] A1 = { 1, 2, 2, 2, 3 };
		int[] A2 = { 2 };

		Assert.assertEquals("[1, 3]", Arrays.toString(test.arraysubstract(A1, A2)));

	}
}
