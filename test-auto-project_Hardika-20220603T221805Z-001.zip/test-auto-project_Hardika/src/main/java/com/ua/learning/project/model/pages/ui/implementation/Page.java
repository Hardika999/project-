package com.ua.learning.project.model.pages.ui.implementation;

public interface Page {

	default void selectMenu(){
		
	}
}
