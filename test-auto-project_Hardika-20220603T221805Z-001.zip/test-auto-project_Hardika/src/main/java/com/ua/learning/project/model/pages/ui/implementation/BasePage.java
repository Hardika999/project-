 package com.ua.learning.project.model.pages.ui.implementation;

 abstract public class BasePage {

	 private String pageURL;
	 
	 protected BasePage(String url){
		 pageURL=url;
	 }
	 
	 public void openWindow(){
		 System.out.println(pageURL);
	 }
}
