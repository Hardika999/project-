package com.ua.learning.project.core.driver;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Collectors;

public class Assignments {

	public static String threeWords(String str1, String str2, String str3) {
		return IntStream.range(0, str1.length())
				.mapToObj(i -> "" + str1.charAt(i) + str2.charAt(i) + str3.charAt(i))
				.collect(Collectors.joining());
	}

	public static int countVovel(String word) {
		return (int) word.chars().filter(c -> "aeiou".indexOf(c) >= 0).count();
	}

	public static int[] arraysubstract(int[] A1, int[] A2) {

		ArrayList<Integer> list = new ArrayList<Integer>();
		Arrays.sort(A2);
		for (int arrElement : A1) {
			if (Arrays.binarySearch(A2, arrElement) < 0)
				list.add(arrElement);
		}
		int[] modifiedArray = new int[list.size()];
		int i = 0;
		for (int elem : list) {
			modifiedArray[i++] = elem;
		}
		return modifiedArray;
	}
}
