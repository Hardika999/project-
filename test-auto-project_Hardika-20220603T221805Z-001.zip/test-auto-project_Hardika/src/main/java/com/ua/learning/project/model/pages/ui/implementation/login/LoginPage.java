package com.ua.learning.project.model.pages.ui.implementation.login;

import com.ua.learning.project.model.pages.ui.implementation.BasePage;

public class LoginPage extends BasePage {

	public LoginPage(String URL){
		super(URL);
	}
}
