package com.ua.learning.project.model.pages.ui.implementation.menu;

import com.ua.learning.project.model.pages.ui.implementation.Page;

public class AbcMenu implements Page{

	public void selectMenu (){
		System.out.println("ABC menu was selected");
	}
}
